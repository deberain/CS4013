public class PropertyOwnerMenu {
}
