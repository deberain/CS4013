public class Property {
    private PropertyOwner owner;
    private Address address;
    private String eircode;
    private double estMarketValue;
    private String locationCategory;
    private boolean principlePrivateResidence;
    private double taxDue;
    private double taxOverdue;

    public Property() {}

    public Property(PropertyOwner owner, Address address, String eircode, double estMarketValue, String locationCategory, boolean principlePrivateResidence) {
        this.owner = owner;
        this.address = address;
        this.eircode = eircode;
        this.estMarketValue = estMarketValue;
        this.locationCategory = locationCategory;
        this.principlePrivateResidence = principlePrivateResidence;
    }

    public double calculateTax() {

    }



}
