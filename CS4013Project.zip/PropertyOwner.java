import java.util.ArrayList;

public class PropertyOwner {
    private String name;
    private Address address;
    private String eircode;
    private ArrayList<Property> properties;
    private double taxDue;
    private double taxOverdue;

    public PropertyOwner() {
        properties = new ArrayList<>();
    }

    public PropertyOwner(String name, Address address, String eircode) {
        properties = new ArrayList<>();
        this.name = name;
        this.address = address;
        this.eircode = eircode;
    }

    public void registerProperty(Property property) {}

    public void payTax(double amount) {

    }

    public void displayProprties() {

    }

    public void getBalance(int year) {

    }

    public void getBalance(Property p) {

    }

    public void calculateTax() {
        double tax = 0;
        for (Property property : properties) {
            tax += property.calculateTax();
        }
        taxDue = tax;
    }


}
